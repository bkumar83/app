"use strict";

module.exports = require("./is-implemented")() ? Array.prototype.entries : require("./shim");
