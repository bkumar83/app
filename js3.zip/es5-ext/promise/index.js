"use strict";

module.exports = { "#": require("./#"), "lazy": require("./lazy") };
