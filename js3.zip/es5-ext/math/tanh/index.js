"use strict";

module.exports = require("./is-implemented")() ? Math.tanh : require("./shim");
