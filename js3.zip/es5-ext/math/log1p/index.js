"use strict";

module.exports = require("./is-implemented")() ? Math.log1p : require("./shim");
