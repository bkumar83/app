"use strict";

if (!require("./is-implemented")()) {
	Object.defineProperty(Number, "isInteger", {
		value: require("./shim"),
		configurable: true,
		enumerable: false,
		writable: true
	});
}
