"use strict";

module.exports = function () { return typeof Number.MIN_SAFE_INTEGER === "number"; };
