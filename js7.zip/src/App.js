import './App.css';
import Sidebar from './components/Sidebar';
import { BrowserRouter as Router, Switch, Route ,Redirect} from 'react-router-dom';
import Home from './pages/Home';
import { Reports, ReportsOne, ReportsTwo, ReportsThree } from './pages/Reports';
import Onboarding from './pages/Onboarding';
import Header from './components/Header';
import Footer from './pages/Footer';
import MyTasks from './components/MyTasks';
import MyTeamTasks from './components/MyTeamTasks';
import Menu from './pages/Menu';
function App() {
  return (
    // <div className="main"> 
    <Router>
      <Header/>
      <Sidebar />
      <Switch>
        <Route path='/' exact component={Home} />
        <Route path='/home' exact component={Home} />
        <Redirect exact from="/home" to="/home/mytasks" />  
       <Route exact path="/home/:page?" render={props => <Home {...props} />} />  

        <Route path='/reports' exact component={Reports} />
        <Route path='/reports/reports1' exact component={ReportsOne} />
        <Route path='/reports/reports2' exact component={ReportsTwo} />
        <Route path='/reports/reports3' exact component={ReportsThree} />
        <Route path='/onboarding' exact component={Onboarding} />
      </Switch>
    
    </Router>
  //   <Footer/>
  //   </div>
   );
}

export default App;
