import React from 'react'
import '../styles/header.css';

const  Header=()=> {
    return (
      <div className="title">
        <h1>NOMURA</h1>
              <div className="Title-Subtitle"></div>
      </div>
    )
  }

  export default Header;