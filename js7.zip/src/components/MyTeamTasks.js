import React from "react";
import '../styles/myteamtasks.css';
const MyTeamTasks = () => {
  return <div className="main">This is   myteam tasks tab</div>;
};

export default MyTeamTasks;