import { Options } from "no-case";
export { Options };
export declare function pascalCaseTransform(input: string, index: number): string;
export declare function pascalCaseTransformMerge(input: string): string;
export declare function pascalCase(input: string, options?: Options): string;
