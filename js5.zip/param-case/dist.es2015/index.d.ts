import { Options } from "dot-case";
export { Options };
export declare function paramCase(input: string, options?: Options): string;
