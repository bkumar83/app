import React from 'react'
import '../styles/footer.css';

const  Footer=()=> {
    return (
      <div className="foot">
        <h3>NOMURA</h3>
      </div>
    )
  }

  export default Footer;