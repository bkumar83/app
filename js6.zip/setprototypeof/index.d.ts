declare function setPrototypeOf(o: any, proto: object | null): any;
export = setPrototypeOf;
